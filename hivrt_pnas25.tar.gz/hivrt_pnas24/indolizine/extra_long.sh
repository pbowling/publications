#! /bin/bash

# Set slurm options for cluster
export SLURMOPTSMD="--time=2880 --ntasks=1 --tasks-per-node=1 --cpus-per-task=1 -p ada5000 --gres=gpu:1 --export=ALL"
export SLURMOPTSPP="--time=2880 --ntasks=1 --tasks-per-node=1 --cpus-per-task=1 -p ada5000 --gres=gpu:1 --mem=50g --export=ALL"

export bump=0.0

# Run long production
DEPEND=""
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=121
  export p
  export nitt=5
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-100%1 $DEPEND ./runset4.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:$PID"
  COMMA=","
done

# Run postprocessing on long production to optimize biases and obtain results
DEPEND=$NEWDEPEND
export i=121
export eqS=25
export S=500
export N=5
export skipE=10
PID=`sbatch --parsable $SLURMOPTSPP $DEPEND ./postprocess.sh`
