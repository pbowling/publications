#!/bin/bash


#python -c "import alf; alf.runflat(151,164,125000,375000,engine='bladelib')"
python -c "import alf; alf.runflat(102,117,125000,375000,engine='bladelib')"
