#! /bin/bash

module load slurm
export nnodes=`cat nnodes`
export nreps=`cat nreps`
export bump=0.0

# DEPEND="--dependency=afterok:"
sbatch --time=2880 --ntasks=$nreps --tasks-per-node=1 --cpus-per-task=$nnodes -p ada5000 --gres=gpu:$nnodes --export=ALL $DEPEND ./runset2.sh
