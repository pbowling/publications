#! /bin/bash

python -c "import alf; alf.postprocess($i,$eqS,$S,$N,$skipE,True,engine='bladelib', G_imp='/home/pbowling/hivrt/cubic/G_imp')"
