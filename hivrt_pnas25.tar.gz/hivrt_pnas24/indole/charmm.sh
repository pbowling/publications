CHARMMEXEC=//export/apps/RockyOS8/charmm/c50a1/bin/charmm
