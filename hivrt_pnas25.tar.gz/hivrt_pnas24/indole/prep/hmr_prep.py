# These are general python modules needed for this  tutorial
import os
import sys
import numpy as np
import subprocess

# These are a subset of the pycharmm modules that were installed when
# pycharmm was installed in your python environment
import pycharmm
import pycharmm.generate as gen
import pycharmm.ic as ic
import pycharmm.coor as coor
import pycharmm.energy as energy
import pycharmm.dynamics as dyn
import pycharmm.nbonds as nbonds
import pycharmm.minimize as minimize
import pycharmm.crystal as crystal
import pycharmm.image as image
import pycharmm.psf as psf
import pycharmm.read as read
import pycharmm.write as write
import pycharmm.settings as settings
import pycharmm.cons_harm as cons_harm
import pycharmm.cons_fix as cons_fix
import pycharmm.select as select
import pycharmm.shake as shake

import pycharmm.lingo as lingo

from pycharmm.lib import charmm as libcharmm

pdbid = 'minimized'
segments = ['LIG', 'P01A', 'P02A', 'P03A', 'P01B', 'P02B', 'P03B', 
            'P04A','P05A','P06A','P07A','P08A','P09A','P10A','P11A',
           'P12A','P13A','P14A', 'WT00', 'IONS']

settings.set_bomb_level(-2)

read.stream('toppar_hmr.str')
read.rtf('core.rtf', append=True)
read.prm('full_ligand.prm', flex=True, append=True)

read.rtf('site1_sub1_pres.rtf', append=True)
read.rtf('site1_sub2_pres.rtf', append=True)
read.rtf('site1_sub3_pres.rtf', append=True)
read.rtf('site1_sub4_pres.rtf', append=True)
read.rtf('site1_sub5_pres.rtf', append=True)
read.rtf('site1_sub6_pres.rtf', append=True)
read.rtf('site1_sub7_pres.rtf', append=True)
read.rtf('site1_sub8_pres.rtf', append=True)

read.rtf('site2_sub1_pres.rtf', append=True)
read.rtf('site2_sub2_pres.rtf', append=True)
read.rtf('site2_sub3_pres.rtf', append=True)
read.rtf('site2_sub4_pres.rtf', append=True)
read.rtf('site2_sub5_pres.rtf', append=True)
read.rtf('site2_sub6_pres.rtf', append=True)
read.rtf('site2_sub7_pres.rtf', append=True)
read.rtf('site2_sub8_pres.rtf', append=True)

read.rtf('site3_sub1_pres.rtf', append=True)
read.rtf('site3_sub2_pres.rtf', append=True)
read.rtf('site3_sub3_pres.rtf', append=True)
read.rtf('site3_sub4_pres.rtf', append=True)
read.rtf('site3_sub5_pres.rtf', append=True)
read.rtf('site3_sub6_pres.rtf', append=True)
read.rtf('site3_sub7_pres.rtf', append=True)
read.rtf('site3_sub8_pres.rtf', append=True)

settings.set_bomb_level(-1)

read.psf_card('aftermin.psf')
read.pdb('minimized.pdb',resid=True)


psf.set_hmr(segments, newpsf='minimized_hmr.psf')
