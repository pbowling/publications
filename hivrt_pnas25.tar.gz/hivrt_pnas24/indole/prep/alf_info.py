import numpy as np
import os
alf_info={}
alf_info['name']='hivrt'
alf_info['nsubs']=[3,4,8,8,8]
alf_info['nblocks']=np.sum(alf_info['nsubs'])
alf_info['ncentral']=0
alf_info['nreps']=1
alf_info['nnodes']=1
alf_info['engine'] = 'charmm'
alf_info['enginepath']=os.environ['CHARMMEXEC']
alf_info['temp']=298.15
