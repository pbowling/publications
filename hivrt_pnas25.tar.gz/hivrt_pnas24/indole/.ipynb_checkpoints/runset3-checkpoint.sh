#!/bin/bash


#python -c "import alf; alf.runflat(151,164,125000,375000,engine='bladelib')"
python -c "import alf; alf.runflat(48,63,125000,375000,engine='bladelib')"
