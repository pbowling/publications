#! /bin/bash

export SLURMOPTSGPU1="--time=1440 --ntasks=1 --tasks-per-node=1 --cpus-per-task=1 -p ada6000 --gres=gpu:1 --export=ALL"
export SLURMOPTSCPU1="--time=1440 --ntasks=1 --tasks-per-node=1 --cpus-per-task=1 -p cpu --export=ALL"
export SLURMOPTSCPU8="--time=1440 --ntasks=1 --tasks-per-node=8 --cpus-per-task=1 -p cpu --export=ALL"

export i=67
export NF=5 #number of independent trials run by runprod
export FREQ=1 #analyzes all frames
export NBS=50 #default value (50)

export PHASE=1
DEPEND="--dependency=afterok:3717839"
PID=`sbatch --parsable $SLURMOPTSCPU1 $DEPEND ./potts.sh`

export PHASE=2
DEPEND="--dependency=afterok:$PID"
PID=`sbatch --parsable $SLURMOPTSCPU1 --array=0-$(( $NF - 1 )) $DEPEND ./potts.sh`

export PHASE=3
DEPEND="--dependency=afterok:$PID"
PID=`sbatch --parsable $SLURMOPTSCPU1 $DEPEND ./potts.sh`

export PHASE=4
DEPEND="--dependency=afterok:$PID"
PID=`sbatch --parsable $SLURMOPTSCPU8 --array=0-$NBS $DEPEND ./potts.sh`

export PHASE=5
DEPEND="--dependency=afterok:$PID"
PID=`sbatch --parsable $SLURMOPTSCPU1 $DEPEND ./potts.sh`
