#! /bin/bash

module load slurm
export nnodes=`cat nnodes`
export nreps=`cat nreps`

export i=234
export eqS=25
export S=100
export N=5
export skipE=10

# DEPEND="--dependency=afterok:"
# --mem=48G
sbatch --time=120:00:00 --ntasks=1 --tasks-per-node=1 --cpus-per-task=2 -p ada5000 --gres=gpu:1 --mem=50g --export=ALL $DEPEND ./postprocess.sh
